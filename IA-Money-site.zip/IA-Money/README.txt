# IA Money

Site inicial responsivo em HTML, CSS e JavaScript puro.

## Como testar
1. Extraia o ZIP.
2. Abra `index.html` no navegador.
3. Teste a busca e os filtros.

## Como publicar
Você pode publicar gratuitamente usando GitHub Pages ou importar o repositório no Vercel.
Envie `index.html` para a raiz do repositório. No Vercel, escolha o projeto e use as configurações padrão para site estático.

## Como ativar monetização (não está ativa ainda)
- Publicidade: crie uma conta com a rede de anúncios escolhida, leia os requisitos atuais, adicione o código fornecido pela própria rede e aguarde aprovação.
- Afiliados: entre em programas oficiais, aguarde aprovação e substitua os links comuns em `index.html` pelos seus links de afiliado.
- Não invente links de afiliado nem use códigos de anúncios de terceiros.
- Para menores de 18 anos, contas, contratos e pagamentos podem exigir um responsável legal. Verifique as regras da plataforma com seu responsável.

## Próximas melhorias
Adicionar páginas de análises originais, política de privacidade, termos de uso, contato real e identificação clara de links afiliados antes de solicitar monetização.
