# ChatCVC — projeto inicial para Vercel

Projeto Next.js responsivo com interface preto/roxo e rota de backend para conversar com a API da OpenAI. A chave fica no servidor, nunca no navegador.

## O que já funciona
- Interface mobile e desktop.
- Chat que chama `/api/chat`.
- Histórico da conversa durante a sessão atual do navegador.
- Tratamento básico de erros e validação das mensagens.

## Ainda não está conectado
Geração de imagens, vídeos, voz, login, banco de dados, pagamentos e limites robustos por usuário ainda precisam ser implementados. Os botões dessas ferramentas são apenas indicações visuais nesta versão.

## Rodar localmente
1. Instale Node.js 20 ou superior.
2. Extraia o ZIP e abra a pasta no terminal.
3. Rode `npm install`.
4. Copie `.env.example` para `.env.local`.
5. No `.env.local`, coloque sua chave real em `OPENAI_API_KEY` e escolha um modelo disponível em `OPENAI_MODEL`.
6. Rode `npm run dev` e abra `http://localhost:3000`.

Nunca publique a chave, não use prefixo `NEXT_PUBLIC_` e não envie a chave por mensagens. A API pode gerar custos conforme o uso. Configure limites e alertas de gastos no provedor antes de liberar para outras pessoas.

## Publicar na Vercel
1. Envie esta pasta para um repositório Git privado.
2. Entre na Vercel e importe o repositório.
3. Em Project Settings → Environment Variables, adicione `OPENAI_API_KEY` e `OPENAI_MODEL`.
4. Faça o deploy. Não coloque a chave em arquivos do projeto ou no código do navegador.

## Antes de lançar publicamente
Adicione autenticação, banco de dados, rate limiting persistente, quotas por plano, proteção contra abuso, política de privacidade, termos de uso e pagamentos. O limite simples desta demonstração não substitui essas proteções.
