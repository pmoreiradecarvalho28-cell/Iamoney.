'use client';

import { FormEvent, useRef, useState } from 'react';

type Message = { role: 'user' | 'assistant'; content: string };
const tools = [
  { icon: '✦', name: 'Conversar', note: 'Disponível' },
  { icon: '▧', name: 'Imagens', note: 'Em breve' },
  { icon: '▶', name: 'Vídeos', note: 'Em breve' },
  { icon: '◖', name: 'Voz', note: 'Em breve' },
  { icon: '⌘', name: 'Programar', note: 'Use o chat' },
  { icon: '▤', name: 'Estudar', note: 'Use o chat' },
];

export default function Home() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [draft, setDraft] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [activeTool, setActiveTool] = useState('Conversar');
  const bottom = useRef<HTMLDivElement>(null);

  async function send(e?: FormEvent, suggestion?: string) {
    e?.preventDefault();
    const content = (suggestion ?? draft).trim();
    if (!content || busy) return;
    const next: Message[] = [...messages, { role: 'user', content }];
    setMessages(next);
    setDraft('');
    setError('');
    setBusy(true);
    try {
      const response = await fetch('/api/chat', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ messages: next.slice(-20) }),
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || 'Não foi possível obter uma resposta.');
      setMessages([...next, { role: 'assistant', content: data.reply }]);
      setTimeout(() => bottom.current?.scrollIntoView({ behavior: 'smooth' }), 50);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Erro inesperado.');
    } finally { setBusy(false); }
  }

  return (
    <main className="shell">
      <aside className="sidebar">
        <a className="brand" href="#home"><span className="brand-mark">✦</span><span>Chat<span className="purple">CVC</span></span></a>
        <button className="new-chat" onClick={() => { setMessages([]); setError(''); }}>＋ <span>Nova conversa</span></button>
        <p className="side-label">FERRAMENTAS</p>
        <nav>{tools.map(t => <button key={t.name} className={`tool-link ${activeTool === t.name ? 'selected' : ''}`} onClick={() => { setActiveTool(t.name); if (t.note === 'Em breve') setError(`${t.name} estará disponível em uma próxima atualização.`); }}><span className="tool-icon">{t.icon}</span><span>{t.name}</span><small>{t.note}</small></button>)}</nav>
        <div className="side-bottom"><div className="plan-card"><span className="sparkle">✧</span><b>ChatCVC Premium</b><p>Mais possibilidades para suas ideias.</p><button onClick={() => setError('Os planos serão ativados quando o sistema de pagamentos estiver configurado.')}>Conhecer planos</button></div><div className="profile"><div className="avatar">C</div><div><b>Visitante</b><small>Plano gratuito</small></div></div></div>
      </aside>

      <section className="main" id="home">
        <header className="topbar"><button className="mobile-brand" onClick={() => setMessages([])}>✦ Chat<span className="purple">CVC</span></button><span className="model-pill"><i /> Assistente IA</span><button className="upgrade" onClick={() => setError('O plano Premium será disponibilizado após a configuração de pagamentos.')}>✧ Seja Premium</button></header>
        <div className="conversation">
          {messages.length === 0 ? <div className="welcome"><div className="orb"><span>✦</span></div><p className="eyebrow">SUA INTELIGÊNCIA. SUAS POSSIBILIDADES.</p><h1>O que vamos <span className="gradient">criar hoje?</span></h1><p className="welcome-copy">Converse, aprenda, programe e transforme suas ideias com o ChatCVC.</p><div className="suggestions"><button onClick={() => send(undefined, 'Me ajude a criar um site moderno.')}>✦ Criar um site moderno</button><button onClick={() => send(undefined, 'Explique inteligência artificial de um jeito simples.')}>▤ Aprender algo novo</button><button onClick={() => send(undefined, 'Me dê ideias para um projeto criativo.')}>✧ Ter ideias criativas</button></div></div> : <div className="messages">{messages.map((m, i) => <div className={`message ${m.role}`} key={i}><div className="message-avatar">{m.role === 'user' ? 'V' : '✦'}</div><div className="message-content"><b>{m.role === 'user' ? 'Você' : 'ChatCVC'}</b><p>{m.content}</p></div></div>)}{busy && <div className="message assistant"><div className="message-avatar">✦</div><div className="message-content"><b>ChatCVC</b><p className="typing">Pensando<span>.</span><span>.</span><span>.</span></p></div></div>}<div ref={bottom}/></div>}
        </div>
        <div className="composer-wrap"><div className="notice">A IA pode cometer erros. Confira informações importantes.</div>{error && <div className="error" role="alert">{error}<button onClick={() => setError('')}>×</button></div>}<form className="composer" onSubmit={send}><textarea value={draft} onChange={e => setDraft(e.target.value)} onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); void send(); } }} placeholder="Pergunte alguma coisa ao ChatCVC..." rows={1} /><div className="composer-bottom"><span>✦ <small>ChatCVC</small></span><button className="send" disabled={!draft.trim() || busy} aria-label="Enviar mensagem">{busy ? '…' : '↑'}</button></div></form><footer>ChatCVC · Feito para transformar ideias em possibilidades.</footer></div>
      </section>
    </main>
  );
}
