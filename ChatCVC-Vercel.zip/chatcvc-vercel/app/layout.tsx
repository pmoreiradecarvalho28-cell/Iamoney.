import type { Metadata, Viewport } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'ChatCVC — Sua inteligência, suas possibilidades',
  description: 'Seu assistente de inteligência artificial.',
  applicationName: 'ChatCVC',
};
export const viewport: Viewport = { themeColor: '#100b1d', width: 'device-width', initialScale: 1 };

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="pt-BR"><body>{children}</body></html>;
}
