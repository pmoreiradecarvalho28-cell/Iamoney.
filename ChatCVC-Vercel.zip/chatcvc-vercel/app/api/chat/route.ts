import OpenAI from 'openai';
import { NextRequest, NextResponse } from 'next/server';

export const runtime = 'nodejs';

export async function POST(request: NextRequest) {
  try {
    if (!process.env.OPENAI_API_KEY) {
      return NextResponse.json({ error: 'A API ainda não foi configurada. Adicione OPENAI_API_KEY nas variáveis de ambiente da Vercel.' }, { status: 503 });
    }
    const body = await request.json();
    const messages = body?.messages;
    if (!Array.isArray(messages) || messages.length === 0 || messages.length > 20) {
      return NextResponse.json({ error: 'Envie uma conversa válida com até 20 mensagens.' }, { status: 400 });
    }
    const clean = messages.map((m: { role?: string; content?: string }) => {
      if (!['user', 'assistant'].includes(m?.role ?? '') || typeof m?.content !== 'string') throw new Error('Mensagem inválida.');
      return { role: m.role as 'user' | 'assistant', content: m.content.slice(0, 6000) };
    });
    if (clean[clean.length - 1].role !== 'user') return NextResponse.json({ error: 'A última mensagem precisa ser do usuário.' }, { status: 400 });

    const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
    const response = await openai.responses.create({
      model: process.env.OPENAI_MODEL || 'gpt-4.1-mini',
      instructions: 'Você é o ChatCVC, um assistente de IA útil, claro e respeitoso. Responda em português brasileiro quando o usuário escrever em português. Não afirme que consegue gerar imagens, vídeos ou áudio se essas ferramentas ainda não estiverem conectadas.',
      input: clean,
      max_output_tokens: 900,
    });
    return NextResponse.json({ reply: response.output_text || 'Não consegui produzir uma resposta. Tente novamente.' });
  } catch (error) {
    console.error('ChatCVC API error:', error);
    const message = error instanceof Error ? error.message : 'Erro interno.';
    return NextResponse.json({ error: message.includes('Mensagem inválida') ? message : 'Ocorreu um erro ao conversar com a IA. Confira a configuração da API e tente novamente.' }, { status: 500 });
  }
}
